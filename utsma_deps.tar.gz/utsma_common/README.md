# UTSMA Common

The `utsma_common` package contains utilities abstracted from individual packages which may find use in other uses. Some examples of things you'll find here:
- Simplified action server
- Simplified service client
- Custom lifecycle node implementation

## Simplified Action Server
## Simplified Service Client

## Custom Lifecyle Node
### Background
Lifecycle Node stems from the idea of regular nodes with managed lifecycle. A managed life cycle for nodes allows greater control over the state of ROS system. It will ensure all components have been instantiated correctly before it allows any component to begin executing its behaviour. It will also allow nodes to be restarted or replaced on-line. Further information about ROS2 default lifecycle node implementation can be found here: https://design.ros2.org/articles/node_lifecycle.html

In addition to the default behaviour provided by ROS2, the custom lifecycle node also provides a heartbeat mechanism utilising ROS2 Quality of Service. Further information about ROS2 QoS can be found here: https://docs.ros.org/en/rolling/Concepts/Intermediate/About-Quality-of-Service-Settings.html and here: https://design.ros2.org/articles/qos. A heartbeat mechanism is a periodic signal sent by a system or a component to indicate its operational status, which serves as a vital component for ensuring system reliability and robustness. The primary purpose of a heartbeat mechanism is to monitor the health and status of nodes or components within a system. By sending regular heartbeat signals, the system can confirm that each component is functioning correctly. If a heartbeat signal is not received within a specified timeframe, it indicates that the component may have failed or is experiencing issues. 



