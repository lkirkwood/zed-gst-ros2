#ifndef UTSMA_COMMON__COMMON_UTILS_HPP_
#define UTSMA_COMMON__COMMON_UTILS_HPP_

#include <mutex>
#include <shared_mutex>
#include <thread>
#include <utility>

namespace utsma_common {
/**
 * @brief A thread-safe wrapper for managing access to an object of type T.
 *
 * This class provides synchronized access to an object of type T using std::shared_mutex for
 * read-write locking.
 *
 * @tparam T The type of the object to be wrapped.
 */
template <typename T>
class ThreadSafeWrapper {
  mutable std::shared_mutex mtx;  ///< Mutex for synchronizing access to the data.
  T data;                         ///< The wrapped object.

 public:
  /**
   * @brief Default constructor.
   */
  ThreadSafeWrapper() = default;

  /**
   * @brief Constructor to wrap an existing instance.
   *
   * @param existing_data The existing instance to be wrapped.
   */
  explicit ThreadSafeWrapper(T existing_data) : data(std::move(existing_data)) {}

  /**
   * @brief Move constructor.
   *
   * @param other The ThreadSafeWrapper to move from.
   */
  ThreadSafeWrapper(ThreadSafeWrapper&& other) noexcept {
    std::unique_lock<std::shared_mutex> lock(other.mtx);
    data = std::move(other.data);
  }

  /**
   * @brief Move assignment operator.
   *
   * @param other The ThreadSafeWrapper to move from.
   * @return Reference to the current instance.
   */
  ThreadSafeWrapper& operator=(ThreadSafeWrapper&& other) noexcept {
    if (this != &other) {
      std::unique_lock<std::shared_mutex> lock_this(mtx, std::defer_lock);
      std::unique_lock<std::shared_mutex> lock_other(other.mtx, std::defer_lock);
      std::lock(lock_this, lock_other);
      data = std::move(other.data);
    }
    return *this;
  }

  /**
   * @brief Deleted copy constructor.
   */
  ThreadSafeWrapper(const ThreadSafeWrapper&) = delete;

  /**
   * @brief Deleted copy assignment operator.
   */
  ThreadSafeWrapper& operator=(const ThreadSafeWrapper&) = delete;

  /**
   * @brief Direct access to the underlying data with an exclusive lock.
   *
   * This method provides direct access to the data for modification.
   *
   * @return Reference to the wrapped object.
   */
  T& get() {
    std::unique_lock<std::shared_mutex> lock(mtx);
    return data;
  }

  /**
   * @brief Direct read-only access to the underlying data with a shared lock.
   *
   * This method provides direct read-only access to the data.
   *
   * @return Const reference to the wrapped object.
   */
  const T& get() const {
    std::shared_lock<std::shared_mutex> lock(mtx);
    return data;
  }
};
}  // namespace utsma_common

#endif