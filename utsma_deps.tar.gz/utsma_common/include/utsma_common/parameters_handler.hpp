#ifndef UTSMA_COMMON__PARAMETERS_HANDLER_HPP_
#define UTSMA_COMMON__PARAMETERS_HANDLER_HPP_

#include <functional>
#include <memory>
#include <string>
#include <type_traits>
#include <unordered_map>
#include <utility>
#include <vector>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "utsma_common/node_utils.hpp"

namespace utsma_common {

template <typename NodeType>
class ParametersHandler {
 public:
  using GetParameterCallback = std::function<void(const rclcpp::Parameter& parameter)>;

  explicit ParametersHandler(const std::weak_ptr<NodeType>& parent) {
    parent_node_ = parent;
    auto node = parent_node_.lock();
    node_name_ = node->get_name();
    on_set_param_handler_ = node->add_on_set_parameters_callback(
        std::bind(&ParametersHandler::dynamic_parameters_callback, this, std::placeholders::_1));
  };
  ~ParametersHandler(){};

  template <typename ParameterT>
  void declare_dynamic_parameter(
      const std::string& param_name, const ParameterT& default_value = {},
      const GetParameterCallback& callback = nullptr,
      const rcl_interfaces::msg::ParameterDescriptor& parameter_descriptor =
          rcl_interfaces::msg::ParameterDescriptor()) {
    auto node = parent_node_.lock();
    if (!node->has_parameter(param_name)) {
      node->declare_parameter(param_name, default_value, parameter_descriptor);
    }
    add_dynamic_parameter_callback(param_name, callback);
  }

  template <typename ParameterT>
  void declare_static_parameter(
      const std::string& param_name, const ParameterT& default_value = {},
      const rcl_interfaces::msg::ParameterDescriptor& parameter_descriptor =
          rcl_interfaces::msg::ParameterDescriptor()) {
    auto node = parent_node_.lock();
    if (!node->has_parameter(param_name)) {
      node->declare_parameter(param_name, default_value, parameter_descriptor);
    }
  }

  template <typename ParameterT>
  void get_parameter(const std::string& name, ParameterT& param_out) {
    auto node = parent_node_.lock();
    ParameterT param{};
    node->get_parameter(name, param);
    param_out = static_cast<ParameterT>(param);
  }

 protected:
  std::mutex parameters_change_mutex_;
  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr on_set_param_handler_;
  std::weak_ptr<NodeType> parent_node_;
  std::string node_name_;

  std::unordered_map<std::string, GetParameterCallback> get_param_callbacks_;

  rcl_interfaces::msg::SetParametersResult dynamic_parameters_callback(
      std::vector<rclcpp::Parameter> parameters) {
    rcl_interfaces::msg::SetParametersResult result;
    std::unique_lock<std::mutex> lock(parameters_change_mutex_);

    for (const rclcpp::Parameter& parameter : parameters) {
      const std::string& parameter_name = parameter.get_name();
      if (auto callback = get_param_callbacks_.find(parameter_name);
          callback != get_param_callbacks_.end()) {
        callback->second(parameter);
      } else {
        // RCLCPP_WARN(logger_, "Parameter %s not found", param_name.c_str());
      }
    }

    result.successful = true;
    return result;
  };

  void add_dynamic_parameter_callback(const std::string& name,
                                      const GetParameterCallback& callback) {
    get_param_callbacks_[name] = callback;
  }

  /**
   * @brief Converts parameter type to real types
   * @param parameter Parameter to convert into real type
   * @return parameter as a functional type
   */
  template <typename T>
  static auto as(const rclcpp::Parameter& parameter) {
    if constexpr (std::is_same_v<T, bool>) {
      return parameter.as_bool();
    } else if constexpr (std::is_integral_v<T>) {
      return parameter.as_int();
    } else if constexpr (std::is_floating_point_v<T>) {
      return parameter.as_double();
    } else if constexpr (std::is_same_v<T, std::string>) {
      return parameter.as_string();
    } else if constexpr (std::is_same_v<T, std::vector<int64_t>>) {
      return parameter.as_integer_array();
    } else if constexpr (std::is_same_v<T, std::vector<double>>) {
      return parameter.as_double_array();
    } else if constexpr (std::is_same_v<T, std::vector<std::string>>) {
      return parameter.as_string_array();
    } else if constexpr (std::is_same_v<T, std::vector<bool>>) {
      return parameter.as_bool_array();
    }
  }
};
}  // namespace utsma_common

#endif
