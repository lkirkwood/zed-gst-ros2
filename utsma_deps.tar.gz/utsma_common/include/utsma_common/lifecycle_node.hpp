#ifndef UTSMA_COMMON__LIFECYCLE_NODE_HPP_
#define UTSMA_COMMON__LIFECYCLE_NODE_HPP_

#include <signal.h>

#include <chrono>
#include <memory>

#include "lifecycle_msgs/msg/state.hpp"
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "std_msgs/msg/u_int16.hpp"
#include "utsma_lifecycle_manager_msgs/srv/register_lifecycle_node.hpp"
#include "utsma_lifecycle_manager_msgs/srv/unregister_lifecycle_node.hpp"

using namespace std::chrono_literals;

namespace utsma_common {
using CallbackReturn = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn;
class LifecycleNode : public rclcpp_lifecycle::LifecycleNode {
 public:
  typedef std::function<void()> QoSMissedLivelinessCallback;
  typedef std::function<void()> QoSMissedDeadlineCallback;

  /**
   * @brief A lifecycle node constructor
   * @param node_name Name for the node
   * @param namespace Namespace for the node, if any
   * @param
   * @param
   * @param options Node options
   */
  LifecycleNode(const std::string& node_name, const std::string& ns = "",
                const double& heartbeat_interval = 1000.0,  // Heartbeat once every second
                const bool& auto_register = true,
                QoSMissedLivelinessCallback missed_liveliness_cb = nullptr,
                QoSMissedDeadlineCallback missed_deadline_cb = nullptr,
                const rclcpp::NodeOptions& options = rclcpp::NodeOptions());
  virtual ~LifecycleNode();

  /**
   * @brief Get a shared pointer of this
   */
  std::shared_ptr<utsma_common::LifecycleNode> shared_from_this() {
    return std::static_pointer_cast<utsma_common::LifecycleNode>(
        rclcpp_lifecycle::LifecycleNode::shared_from_this());
  }

  virtual utsma_common::CallbackReturn on_configure(const rclcpp_lifecycle::State&);

  /**
   * @brief
   *
   * @return utsma_common::CallbackReturn
   */
  virtual utsma_common::CallbackReturn on_activate(const rclcpp_lifecycle::State&);

  /**
   * @brief
   *
   * @return utsma_common::CallbackReturn
   */
  virtual utsma_common::CallbackReturn on_deactivate(const rclcpp_lifecycle::State&);

  /**
   * @brief Abstracted on_error state transition callback, since unimplemented as of 2020
   * in the managed ROS2 node state machine
   * @param state State prior to error transition
   * @return Return type for success or failed transition to error state
   */
  virtual utsma_common::CallbackReturn on_error(const rclcpp_lifecycle::State&) {
    RCLCPP_FATAL(get_logger(), "Lifecycle node %s does not have error state implemented",
                 get_name());
    return utsma_common::CallbackReturn::SUCCESS;
  }

  /**
   * @brief
   *
   */
  bool send_heartbeat();

  /**
   * @brief
   *
   * @return true
   * @return false
   */
  bool register_with_manager();

  /**
   * @brief
   *
   * @return true
   * @return false
   */
  bool unregister_with_manager();

 protected:
  bool auto_register_;
  QoSMissedLivelinessCallback missed_liveliness_cb_;
  QoSMissedDeadlineCallback missed_deadline_cb_;

  // Heartbeat stuff should be private as it is designed to work in the background
 private:
  std::unique_ptr<rclcpp::PreShutdownCallbackHandle> rcl_preshutdown_cb_handle_{nullptr};
  rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::UInt16>::SharedPtr heartbeat_publisher_;

  // Heartbeat
  std::chrono::milliseconds interval_;
  rclcpp::QoS heartbeat_qos_profile_;
  double heartbeat_interval_;
  bool initialized_;
  bool registered_;

  /**
   * @brief
   *
   * @return true
   * @return false
   */
  bool initial_registration_within_manager();

  /**
   * @brief Create a heartbeat publisher with custom QoS
   *
   */
  bool create_heartbeat_publisher();

  /**
   * @brief
   *
   */
  bool stop_heartbeat_pubisher();

  /**
   * @brief Print notifications for lifecycle node
   */
  void print_lifecycle_node_notification();

  /**
   * Register our preshutdown callback for this Node's rcl Context.
   * The callback fires before this Node's Context is shutdown.
   * Note this is not directly related to the lifecycle state machine.
   */
  void register_rcl_preshutdown_callback();

  /**
   * Run some common cleanup steps shared between rcl preshutdown and destruction.
   */
  void run_cleanups();

  /**
   * @brief Perform preshutdown activities before our Context is shutdown.
   * Note that this is related to our Context's shutdown sequence, not the
   * lifecycle node state machine.
   */
  void on_rcl_preshutdown();
};
}  // namespace utsma_common

#endif
