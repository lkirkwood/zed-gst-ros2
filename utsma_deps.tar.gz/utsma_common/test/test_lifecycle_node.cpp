#include <chrono>
#include <memory>

#include "gtest/gtest.h"
#include "rclcpp/rclcpp.hpp"
#include "utsma_common/lifecycle_node.hpp"
#include "utsma_lifecycle_manager_msgs/srv/register_lifecycle_node.hpp"
#include "utsma_lifecycle_manager_msgs/srv/unregister_lifecycle_node.hpp"

using namespace std::placeholders;
using namespace std::chrono_literals;
using RegisterLifecycleNode = utsma_lifecycle_manager_msgs::srv::RegisterLifecycleNode;
using UnregisterLifecycleNode = utsma_lifecycle_manager_msgs::srv::UnregisterLifecycleNode;

/**
 * @brief Simple LifecycleManagerServerNode to test LifecycleNode monitoring
 *
 */
class LifecycleManagerServerNode : public rclcpp::Node {
 public:
  LifecycleManagerServerNode()
      : rclcpp::Node("lifecycle_manager_node"), total_heartbeat_received(0) {}
  ~LifecycleManagerServerNode(){};

  void on_init() {
    total_heartbeat_received = 0;
    register_service_server_ = shared_from_this()->create_service<RegisterLifecycleNode>(
        "/lifecycle_manager/register_lifecycle_node",
        std::bind(&LifecycleManagerServerNode::register_callback, this, _1, _2));
    unregister_service_server_ = shared_from_this()->create_service<UnregisterLifecycleNode>(
        "/lifecycle_manager/unregister_lifecycle_node",
        std::bind(&LifecycleManagerServerNode::unregister_callback, this, _1, _2));

    rclcpp::QoS qos_profile(1);
    qos_profile.keep_last(1);  // Only keep last one message
    qos_profile.reliability(rclcpp::ReliabilityPolicy::Reliable)
        .durability(rclcpp::DurabilityPolicy::Volatile)
        .liveliness(rclcpp::LivelinessPolicy::ManualByTopic)
        .liveliness_lease_duration(101ms)
        .deadline(101ms);
    // Added node options
    rclcpp::SubscriptionOptions options;
    // Bind callbacks to handle heartbeat drop cases
    options.event_callbacks.liveliness_callback =
        [this](rclcpp::QOSLivelinessChangedInfo& event) -> void {
      if (event.alive_count == 0) {
        RCLCPP_INFO(get_logger(),
                    "Liveliness changed: alive_count_changed = %d, not_alive_count_changed = %d",
                    event.alive_count_change, event.not_alive_count_change);
        RCLCPP_INFO(get_logger(), "Liveliness changed: alive_count = %d, not_alive_count = %d",
                    event.alive_count, event.not_alive_count);
        RCLCPP_ERROR(get_logger(), "Node is unhealthy due to liveliness");
      }
    };
    options.event_callbacks.deadline_callback =
        [this](rclcpp::QOSDeadlineRequestedInfo& event) -> void {
      // If we missed a single heartbeat -> the node is unhealthy
      if (event.total_count == 0) {
        RCLCPP_ERROR(get_logger(), "Node is unhealthy due to deadline");
      }
    };
    heartbeat_sub_ = shared_from_this()->create_subscription<std_msgs::msg::UInt16>(
        "/test_node/heartbeat", qos_profile,
        [this](std_msgs::msg::UInt16::SharedPtr) { total_heartbeat_received++; }, options);
  };

  void on_term() {
    register_service_server_.reset();
    unregister_service_server_.reset();
  };

  void reset() { total_heartbeat_received = 0; }

  unsigned int get_total_heartbeat_received() { return total_heartbeat_received; }

 private:
  rclcpp::Service<RegisterLifecycleNode>::SharedPtr register_service_server_;
  rclcpp::Service<UnregisterLifecycleNode>::SharedPtr unregister_service_server_;
  rclcpp::Subscription<std_msgs::msg::UInt16>::SharedPtr heartbeat_sub_;
  unsigned int total_heartbeat_received;

  void register_callback(RegisterLifecycleNode::Request::SharedPtr,
                         RegisterLifecycleNode::Response::SharedPtr res) {
    RCLCPP_INFO(get_logger(), "Received registration");
    res->success = true;
    res->message = "Success";
  };

  void unregister_callback(UnregisterLifecycleNode::Request::SharedPtr,
                           UnregisterLifecycleNode::Response::SharedPtr res) {
    res->success = true;
    res->message = "Success";
  };
};

class RclCppFixture {
 public:
  RclCppFixture() {}

  void setup() {
    server_thread_ =
        std::make_shared<std::thread>(std::bind(&RclCppFixture::server_thread_func, this));
  }

  void reset() { node_->reset(); }

  ~RclCppFixture() { server_thread_->join(); }

  void server_thread_func() {
    node_ = std::make_shared<LifecycleManagerServerNode>();
    node_->on_init();
    rclcpp::spin(node_->get_node_base_interface());
    node_->on_term();
    node_.reset();
  }

  unsigned int get_total_heartbeat_received() { return node_->get_total_heartbeat_received(); }
  std::shared_ptr<std::thread> server_thread_;
  std::shared_ptr<LifecycleManagerServerNode> node_;
};

RclCppFixture g_rclcppfixture;

class TestLifecycleNode : public utsma_common::LifecycleNode {
 public:
  TestLifecycleNode(const double& interval)
      : LifecycleNode("test_node", "", 100.0, true, nullptr, nullptr, rclcpp::NodeOptions()) {
    timer_ = create_wall_timer(100ms, std::bind(&TestLifecycleNode::timer_callback, this));
  };

 protected:
  rclcpp::TimerBase::SharedPtr timer_;
  void timer_callback() { send_heartbeat(); }
};

class LifecycleNodeTestP : public ::testing::TestWithParam<double> {
 protected:
  void SetUp() override {
    interval_ = GetParam();
    node_ = std::make_shared<TestLifecycleNode>(100.0);
    stop_thread_ = false;
    // Spin this node in a separate thread
    spin_thread_ =
        std::make_shared<std::thread>(std::bind(&LifecycleNodeTestP::spin_thread_func, this));
  }

  void spin_thread_func() {
    while (rclcpp::ok() && !stop_thread_) {
      rclcpp::spin_some(node_->get_node_base_interface());
    }
  }

  void TearDown() override {
    stop_thread_ = true;
    if (spin_thread_->joinable()) {
      spin_thread_->join();
    }
    node_.reset();
  }

  std::shared_ptr<utsma_common::LifecycleNode> node_;
  std::shared_ptr<std::thread> spin_thread_;
  std::atomic<bool> stop_thread_;
  double interval_;
};

// For the following two tests, if the LifecycleNode doesn't shut down properly,
// the overall test will hang since the rclcpp thread will still be running,
// preventing the executable from exiting (the test will hang)
// These are the 2 default tests from Nav2

TEST(LifecycleNode, test_node_exits_cleanly) {
  // Make sure the node exits cleanly when using an rclcpp_node and associated thread
  auto node1 = std::make_shared<utsma_common::LifecycleNode>("test_node", "");
  std::this_thread::sleep_for(std::chrono::seconds(1));
  SUCCEED();
}

TEST(LifecycleNode, test_multiple_nodes_exit_cleanly) {
  // Try a couple nodes w/ rclcpp_node and threads
  auto node1 = std::make_shared<utsma_common::LifecycleNode>("test_node1", "");
  auto node2 = std::make_shared<utsma_common::LifecycleNode>("test_node2", "");

  std::this_thread::sleep_for(std::chrono::seconds(1));
  SUCCEED();
}

TEST_P(LifecycleNodeTestP, test_heartbeat_normal) {
  // Reset fixture first
  g_rclcppfixture.reset();
  auto state = node_->configure();
  EXPECT_EQ(state.id(), lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE);
  // Heartbeat should not be published at this point so we expect 0 heartbeat received
  RCLCPP_INFO(node_->get_logger(), "Long time execution");
  std::this_thread::sleep_for(std::chrono::seconds(2));
  EXPECT_EQ(g_rclcppfixture.get_total_heartbeat_received(), 0);

  // Now activate the lifecycle node
  state = node_->activate();
  EXPECT_EQ(state.id(), lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE);
  // Sleep for 2 seconds -> expect 20 heartbeat messages
  RCLCPP_INFO(node_->get_logger(), "Long time execution");
  std::this_thread::sleep_for(std::chrono::seconds(2));
  EXPECT_NEAR(g_rclcppfixture.get_total_heartbeat_received(), 20, 1);
  SUCCEED();
}

TEST_P(LifecycleNodeTestP, test_heartbeat_when_deactivated) {
  // Reset fixture first
  g_rclcppfixture.reset();
  auto state = node_->configure();
  EXPECT_EQ(state.id(), lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE);
  state = node_->activate();
  EXPECT_EQ(state.id(), lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE);
  // Sleep for 2 seconds -> expect 20 heartbeat messages
  std::this_thread::sleep_for(std::chrono::seconds(2));
  EXPECT_NEAR(g_rclcppfixture.get_total_heartbeat_received(), 20, 1);
  // Deactivate node and sleep for another 2s, total heartbeat should still be 20
  state = node_->deactivate();
  EXPECT_EQ(state.id(), lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE);
  std::this_thread::sleep_for(std::chrono::seconds(2));
  // Add slight tolerance to ensure cases where the transition happens during publishing
  EXPECT_NEAR(g_rclcppfixture.get_total_heartbeat_received(), 20, 1);
  SUCCEED();
}

INSTANTIATE_TEST_SUITE_P(LifecycleTestSuite, LifecycleNodeTestP, ::testing::Values(100.0));

int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  g_rclcppfixture.setup();
  ::testing::InitGoogleTest(&argc, argv);
  auto result = RUN_ALL_TESTS();
  rclcpp::shutdown();
  return result;
}
