#include <chrono>
#include <memory>

#include "rclcpp/rclcpp.hpp"
#include "utsma_common/lifecycle_node.hpp"

/**
 * This class provides an example of how to properly use and setup a custom lifecycle node with
 * heartbeat publishing mechanism. Let's build our class based on the following scenario:
 *
 */
class ExampleLifecycleNode : public utsma_common::LifecycleNode {
 public:
  /**
   * In this constructor it is important to initialise the base class in the initializer list. For
   * this example, we initialize a LifecycleNode with name "example_node", namespace "", 1000.0
   * milliseconds of heartbeat interval and default node options.
   *
   */
  ExampleLifecycleNode()
      : utsma_common::LifecycleNode("example_node", "", 1000.0, false, nullptr, nullptr,
                                    rclcpp::NodeOptions()) {
    // Create our work thread timer here as usual and set the desired frequency.
    work_timer_ = create_wall_timer(100ms, std::bind(&ExampleLifecycleNode::work_callback, this));
  };

  ~ExampleLifecycleNode(){};

  /**
   * Implement state transition callback function as how they would be implemented for the default
   * lifecycle node normally
   *
   */

  utsma_common::CallbackReturn on_cleanup(const rclcpp_lifecycle::State&) {
    RCLCPP_INFO(get_logger(), "on_cleanup callback");
    return utsma_common::CallbackReturn::SUCCESS;
  }

  utsma_common::CallbackReturn on_shutdown(const rclcpp_lifecycle::State&) {
    RCLCPP_INFO(get_logger(), "on_shutdown callback");
    return utsma_common::CallbackReturn::SUCCESS;
  }

  /**
   * Specifically for these 3 functions on_configure, on_activate and on_deactivate, please remember
   * to return the base class implementation of these three functions at the end as they handle
   * configurations of ros networking setup, the activating and deactivating of the watchdog
   * heartbeat publisher.
   *
   * @return utsma_common::CallbackReturn
   */
  utsma_common::CallbackReturn on_configure(const rclcpp_lifecycle::State& state) {
    RCLCPP_INFO(get_logger(), "on_configure callback");
    return LifecycleNode::on_activate(state);
  }
  utsma_common::CallbackReturn on_activate(const rclcpp_lifecycle::State& state) {
    RCLCPP_INFO(get_logger(), "on_activate callback");
    // VERY IMPORTANT: Return the base class implementation of this function to ensure the heartbeat
    // publisher is activated properly
    return LifecycleNode::on_activate(state);
  }

  utsma_common::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& state) {
    RCLCPP_INFO(get_logger(), "on_deactivate callback");
    // VERY IMPORTANT: Return the base class implementation of this function to ensure the heartbeat
    // publisher is deactivated properly
    return utsma_common::CallbackReturn::SUCCESS;
  }

 protected:
  /**
   * Timer here to illstrate the work that this node has to do. For example, it might need to
   * calculate control command for a robot and publish it at a certain freqency. This work_timer_ is
   * an example handle of such work.
   *
   */
  rclcpp::TimerBase::SharedPtr work_timer_;

  /**
   * Long work callback function associated with the above timer. It is VERY IMPORTANT to RESET the
   * watchdog heartbeat timer simply by calling send_heartbeat(), ideally in this loop. The
   * rationale behind this is to ensure that any long execution work that renders the node
   * unresponsive can be quickly identified as the node becomes unable to send regular heartbeats.
   * It is also recommended not to bypass this design choice by reseting the watchdog in a separate
   * thread from the main work thread as it defeats the purpose of ensuring the main work done in
   * this node would not render it unresponsive.
   *
   */
  void work_callback() {
    // Some long execution that took 90ms
    rclcpp::sleep_for(std::chrono::milliseconds(90));
    send_heartbeat();
  }
};