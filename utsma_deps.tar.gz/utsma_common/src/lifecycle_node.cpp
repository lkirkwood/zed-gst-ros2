#include "utsma_common/lifecycle_node.hpp"

namespace utsma_common {
LifecycleNode::LifecycleNode(const std::string &node_name,
                             const std::string &ns,
                             const double &default_heartbeat_interval,
                             const bool &auto_register,
                             QoSMissedLivelinessCallback missed_liveliness_cb,
                             QoSMissedDeadlineCallback missed_deadline_cb,
                             const rclcpp::NodeOptions &options)
    : rclcpp_lifecycle::LifecycleNode(node_name, ns, options),
      heartbeat_qos_profile_(1), auto_register_(auto_register),
      heartbeat_interval_(default_heartbeat_interval),
      missed_liveliness_cb_(missed_liveliness_cb),
      missed_deadline_cb_(missed_deadline_cb), initialized_(false),
      registered_(false) {
  // Allow options for user to configure node behaviour, in this case configure
  // heartbeat interval If user does not provide input, use the default
  // arguments provided
  declare_parameter("heartbeat_interval", rclcpp::PARAMETER_DOUBLE);

  if (auto_register_) {
    RCLCPP_INFO(get_logger(),
                "Registering lifecylce node with lifecycle manager");
    if (!initial_registration_within_manager()) {
      RCLCPP_ERROR(get_logger(),
                   "Unable to register lifecycle node with lifecycle manager");
    }
    // Successfully register with server
    registered_ = true;
  }

  // Done background initialization
  initialized_ = true;

  register_rcl_preshutdown_callback();
}

LifecycleNode::~LifecycleNode() {
  RCLCPP_INFO(get_logger(), "Destroying Lifecycle Node");
  run_cleanups();

  rclcpp::Context::SharedPtr context = get_node_base_interface()->get_context();
  if (rcl_preshutdown_cb_handle_) {
    context->remove_pre_shutdown_callback(*(rcl_preshutdown_cb_handle_.get()));
    rcl_preshutdown_cb_handle_.reset();
  }
  // Quickly logs shutdown reason
  RCLCPP_INFO(get_logger(), "Shutdown reason: %s",
              context->shutdown_reason().c_str());
}

utsma_common::CallbackReturn
LifecycleNode::on_configure(const rclcpp_lifecycle::State &) {
  // Configuring ROS networking setup and parameters
  // Check if heartbeat_interval exists or has values, if not the use default
  get_parameter("heartbeat_interval", heartbeat_interval_);

  rclcpp::Duration liveliness_interval(
      std::chrono::milliseconds(static_cast<int64_t>(
          heartbeat_interval_ + 1))); // Additional 10ms to compensate for the
                                      // mistiming when publishing messages
  rclcpp::Duration deadline_interval(
      std::chrono::milliseconds(static_cast<int64_t>(heartbeat_interval_)));
  // Initialise QoS configuration for heartbeat
  heartbeat_qos_profile_
      .keep_last(1) // Only keep last one message
      .reliability(rclcpp::ReliabilityPolicy::Reliable) // Spam until heartbeat
                                                        // reaches watchdog
      .durability(rclcpp::DurabilityPolicy::Volatile)
      .liveliness(rclcpp::LivelinessPolicy::ManualByTopic) // The topic itself
                                                           // has to be HEALTHY
      .liveliness_lease_duration(liveliness_interval);     //
  heartbeat_qos_profile_.deadline(deadline_interval);

  // During construction, technically there is no executor currently spinning
  // the node. As such, it is ok to temporary spin the node locally here just to
  // register it with the lifecycle manager
  RCLCPP_INFO(get_logger(), "Creating heartbeat publisher", get_name());
  create_heartbeat_publisher();

  if (!auto_register_) {
    register_with_manager();
  }

  return utsma_common::CallbackReturn::SUCCESS;
}

utsma_common::CallbackReturn
LifecycleNode::on_activate(const rclcpp_lifecycle::State &) {
  RCLCPP_INFO(get_logger(), "Start publishing heartbeat...");
  heartbeat_publisher_->on_activate();
  return utsma_common::CallbackReturn::SUCCESS;
}

utsma_common::CallbackReturn
LifecycleNode::on_deactivate(const rclcpp_lifecycle::State &) {
  RCLCPP_INFO(get_logger(), "Stop publishing heartbeat...");
  heartbeat_publisher_->on_deactivate();
  return utsma_common::CallbackReturn::SUCCESS;
}

void LifecycleNode::on_rcl_preshutdown() {
  RCLCPP_INFO(get_logger(), "Running lifecycle node rcl preshutdown (%s)",
              this->get_name());
  run_cleanups();
  // Check if manager is still alive
  bool manager_alive = false;
  auto node_names = get_node_graph_interface()->get_node_names();
  for (const auto &name : node_names) {
    if (name == "/lifecycle_manager") {
      manager_alive = true;
    }
  }
  // Unregister with manager first, try for 5 times
  if (registered_ && manager_alive) {
    for (unsigned int tries = 0; tries < 5 && !unregister_with_manager();
         tries++)
      ;
  }
  // then stop publishing heartbeat
  stop_heartbeat_pubisher();
}

bool LifecycleNode::initial_registration_within_manager() {
  if (initialized_) {
    RCLCPP_ERROR(this->get_logger(),
                 "Cannot perform initial registration with manager. Exiting..");
    return false;
  }
  std::string service = "/lifecycle_manager/register_lifecycle_node";
  auto client =
      create_client<utsma_lifecycle_manager_msgs::srv::RegisterLifecycleNode>(
          service);
  // Block until server is up
  rclcpp::Rate r(20);
  while (!client->wait_for_service(2s)) {
    if (!rclcpp::ok()) {
      RCLCPP_ERROR(
          this->get_logger(),
          "Interrupted while waiting for the lifecycle manager. Exiting.");
      return false;
    }
    RCLCPP_INFO(this->get_logger(),
                "Lifecycle Manager not available, waiting again...");
    r.sleep();
  }
  auto request = std::make_shared<
      utsma_lifecycle_manager_msgs::srv::RegisterLifecycleNode::Request>();
  request->node_name = get_name();
  request->heartbeat_topic = "heartbeat";
  request->qos_reliability = (uint8_t)heartbeat_qos_profile_.reliability();
  request->qos_durability = (uint8_t)heartbeat_qos_profile_.durability();
  request->qos_liveliness = (uint8_t)heartbeat_qos_profile_.liveliness();

  // Extract liveliness duration
  rclcpp::Duration liveliness_lease_duration =
      heartbeat_qos_profile_.liveliness_lease_duration();
  auto liveliness_ms =
      std::chrono::duration_cast<std::chrono::milliseconds>(
          liveliness_lease_duration.to_chrono<std::chrono::nanoseconds>())
          .count();
  request->qos_liveliness_lease_duration = static_cast<float>(liveliness_ms);

  // Extract deadline duration
  rclcpp::Duration deadline = heartbeat_qos_profile_.deadline();
  auto deadline_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                         deadline.to_chrono<std::chrono::nanoseconds>())
                         .count();
  request->heartbeat_interval = static_cast<float>(deadline_ms);

  // Send request
  auto future = client->async_send_request(request);
  try {
    auto result = rclcpp::spin_until_future_complete(get_node_base_interface(),
                                                     future, 2s);
    auto response = future.get();
    if (result != rclcpp::FutureReturnCode::SUCCESS) {
      // Pending request must be manually cleaned up if execution is interrupted
      // or timed out
      client->remove_pending_request(future);
    }
    if (response->success) {
      RCLCPP_INFO(get_logger(), "Registration successful: %s",
                  response->message.c_str());
      return true;
    } else {
      RCLCPP_ERROR(get_logger(), "Registration failed: %s",
                   response->message.c_str());
      return false;
    }
  } catch (const std::exception &e) {
    RCLCPP_ERROR(get_logger(), "Registration service call failed: %s",
                 e.what());
    return false;
  }
}

bool LifecycleNode::register_with_manager() {
  std::string service = "/lifecycle_manager/register_lifecycle_node";
  auto client =
      create_client<utsma_lifecycle_manager_msgs::srv::RegisterLifecycleNode>(
          service);
  // Block until server is up
  if (!client->wait_for_service(2s)) {
    if (!rclcpp::ok()) {
      RCLCPP_ERROR(
          this->get_logger(),
          "Interrupted while waiting for the lifecycle manager. Exiting.");
      return false;
    }
    RCLCPP_INFO(this->get_logger(),
                "Lifecycle Manager not available, waiting again...");
    return false;
  }
  auto request = std::make_shared<
      utsma_lifecycle_manager_msgs::srv::RegisterLifecycleNode::Request>();
  request->node_name = get_name();
  request->heartbeat_topic = "heartbeat";
  request->qos_reliability = (uint8_t)heartbeat_qos_profile_.reliability();
  request->qos_durability = (uint8_t)heartbeat_qos_profile_.durability();
  request->qos_liveliness = (uint8_t)heartbeat_qos_profile_.liveliness();

  // Extract liveliness duration
  rclcpp::Duration liveliness_lease_duration =
      heartbeat_qos_profile_.liveliness_lease_duration();
  auto liveliness_ms =
      std::chrono::duration_cast<std::chrono::milliseconds>(
          liveliness_lease_duration.to_chrono<std::chrono::nanoseconds>())
          .count();
  request->qos_liveliness_lease_duration = static_cast<float>(liveliness_ms);

  // Extract deadline duration
  rclcpp::Duration deadline = heartbeat_qos_profile_.deadline();
  auto deadline_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                         deadline.to_chrono<std::chrono::nanoseconds>())
                         .count();
  request->heartbeat_interval = static_cast<float>(deadline_ms);

  // Send request
  auto future = client->async_send_request(request);
  try {
    auto response = future.get();
    if (future.get()->success) {
      RCLCPP_INFO(get_logger(), "Registration successful: %s",
                  future.get()->message.c_str());
      return true;
    } else {
      RCLCPP_ERROR(get_logger(), "Registration failed: %s",
                   future.get()->message.c_str());
      return false;
    }
  } catch (const std::exception &e) {
    RCLCPP_ERROR(get_logger(), "Registration service call failed: %s",
                 e.what());
    return false;
  }
}

bool LifecycleNode::unregister_with_manager() {
  RCLCPP_INFO(this->get_logger(), "Unregistering with manager");
  std::string service = "/lifecycle_manager/unregister_lifecycle_node";
  auto client =
      create_client<utsma_lifecycle_manager_msgs::srv::UnregisterLifecycleNode>(
          service);
  if (!client->wait_for_service(1s)) {
    if (!rclcpp::ok()) {
      RCLCPP_ERROR(
          this->get_logger(),
          "Interrupted while waiting for the lifecycle manager. Exiting.");
      return false;
    }
    RCLCPP_ERROR(this->get_logger(), "Lifecycle Manager not available");
    return false;
  }
  auto request = std::make_shared<
      utsma_lifecycle_manager_msgs::srv::UnregisterLifecycleNode::Request>();
  request->node_name = get_name();

  // Send request
  auto future = client->async_send_request(request);
  try {
    auto response = future.get();
    if (response->success) {
      RCLCPP_INFO(get_logger(), "Unregistration successful: %s",
                  response->message.c_str());
      return true;
    } else {
      RCLCPP_ERROR(get_logger(), "Unregistration failed: %s",
                   response->message.c_str());
      return false;
    }
  } catch (const std::exception &e) {
    RCLCPP_ERROR(get_logger(), "Unregistration service call failed: %s",
                 e.what());
    return false;
  }
}

bool LifecycleNode::create_heartbeat_publisher() {
  std::string node_name = get_node_base_interface()->get_fully_qualified_name();
  if (!heartbeat_publisher_) {
    // Minimal publisher for publishing heartbeats
    std::string topic_name = node_name + "/heartbeat";
    rclcpp::PublisherOptions options;
    // Added event callback to handle case where heartbeat publisher fails to
    // publish heartbeat
    options.event_callbacks.deadline_callback =
        [this](rclcpp::QOSDeadlineOfferedInfo &info) -> void {
      // Execute user-defined cb
      if (missed_liveliness_cb_) {
        missed_liveliness_cb_();
      }
    };
    options.event_callbacks.liveliness_callback =
        [this](rclcpp::QOSLivelinessLostInfo &info) -> void {
      // Execute user-defined cb
      if (missed_deadline_cb_) {
        missed_deadline_cb_();
      }
    };
    heartbeat_publisher_ = create_publisher<std_msgs::msg::UInt16>(
        topic_name, heartbeat_qos_profile_, options);
  }

  return true;
}

bool LifecycleNode::stop_heartbeat_pubisher() {
  if (heartbeat_publisher_) {
    heartbeat_publisher_->on_deactivate();
    heartbeat_publisher_.reset();
    return true;
  }
  return false;
}

bool LifecycleNode::send_heartbeat() {
  if (heartbeat_publisher_) {
    // Reset watchdog to ensure the node is alive
    heartbeat_publisher_->assert_liveliness();

    // Publish heartbeat
    std_msgs::msg::UInt16 heartbeat;
    heartbeat.data = 0.0;
    // Only publish data is publisher is in active state
    if (heartbeat_publisher_->is_activated()) {
      heartbeat_publisher_->publish(heartbeat);
    }
    return true;
  }
  return false;
}

void LifecycleNode::print_lifecycle_node_notification() {
  RCLCPP_INFO(get_logger(), "\n\t%s lifecycle node launched.", get_name());
}

void LifecycleNode::register_rcl_preshutdown_callback() {
  rclcpp::Context::SharedPtr context = get_node_base_interface()->get_context();
  rcl_preshutdown_cb_handle_ =
      std::make_unique<rclcpp::PreShutdownCallbackHandle>(
          context->add_pre_shutdown_callback(
              std::bind(&LifecycleNode::on_rcl_preshutdown, this)));
}

void LifecycleNode::run_cleanups() {
  /*
   * In case this lifecycle node wasn't properly shut down, do it here.
   * We will give the user some ability to clean up properly here, but it's
   * best effort; i.e. we aren't trying to account for all possible states.
   */
  if (get_current_state().id() ==
      lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE) {
    deactivate();
  }
  if (get_current_state().id() ==
      lifecycle_msgs::msg::State::PRIMARY_STATE_INACTIVE) {
    cleanup();
  }
}
} // namespace utsma_common
